export class Employee {

    //this is a DTO for jason data 
    //we use this for Updating 
    "id": number=0;
    "name": string="";
    "address":string= "";
    "phone":number= 0;
    "country":string= "";
}
